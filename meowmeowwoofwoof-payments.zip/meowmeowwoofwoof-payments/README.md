# MeowMeowWoofWoof checkout integration

The original cartoon storefront is preserved. Checkout now requests a Stripe Checkout session from a Node server. It never stores card numbers. The server calculates prices itself and requires an approved pet registry ID.

## Setup
1. Install Node.js 20+. Run `npm install` in this folder.
2. Copy `.env.example` to `.env`, set your own Stripe keys and `PUBLIC_SITE_URL`. Start with Stripe TEST keys.
3. Add **real, verified** recipient entries to `verified-registries.json` in this format (do not publish fabricated recipient records): `{"approved-id":{"status":"verified","kind":"cat","displayName":"Public pet name"}}`. Only add recipients after verifying eligibility and permission, and arranging fulfillment.
4. Run `npm start` and visit `http://localhost:3000`.
5. Set up a Stripe webhook pointing to `/api/stripe-webhook` and provide its signing secret. Use Stripe test cards to verify checkout, returns, and webhooks.

## Not production-ready until these are addressed
- Stripe payment account and live domain must be configured by the site owner.
- **No actual fulfillment is automated.** A paid order is only logged. Build a durable database, idempotent webhook order records, recipient allocation, refunds, delivery/clinic settlement, reconciliation and receipts before accepting real customer money.
- Recipient verification, legal entity, donation/tax language, payment policies, privacy, fraud prevention, order limits and customer support must be established.
- Current registry JSON is a temporary owner-maintained allowlist, not a secure recipient onboarding system. No real recipients are included.
- Coins are browser-local thank-you points, not transferable or redeemable; production rewards need a server-side ledger.
- Payment status endpoint is only for showing a success screen; the signed webhook and database must be the source of truth for fulfillment.
