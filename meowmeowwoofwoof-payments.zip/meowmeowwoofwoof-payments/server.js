import 'dotenv/config';
import express from 'express';
import Stripe from 'stripe';
import {readFileSync} from 'node:fs';
const app=express();
const stripe=process.env.STRIPE_SECRET_KEY?new Stripe(process.env.STRIPE_SECRET_KEY):null;
const products={cat:[['Cat food',2200],['Wet food',1400],['Yarn toy',800],['Feather wand',1100],['Cozy cat bed',2800],['Vet care gift',2500]],dog:[['Dog food',2900],['Wet food',1700],['Tennis ball',700],['Plush toy',1200],['Cozy dog bed',3500],['Vet care gift',2500]]};
let registries={};try{registries=JSON.parse(readFileSync(new URL('./verified-registries.json',import.meta.url),'utf8'))}catch{}
// Verify webhook signatures using the raw request body. Replace this log with durable order storage + fulfillment workflow before launch.
app.post('/api/stripe-webhook',express.raw({type:'application/json'}),(req,res)=>{
 if(!stripe||!process.env.STRIPE_WEBHOOK_SECRET)return res.sendStatus(503);
 let event;try{event=stripe.webhooks.constructEvent(req.body,req.headers['stripe-signature'],process.env.STRIPE_WEBHOOK_SECRET)}catch{return res.sendStatus(400)}
 if(event.type==='checkout.session.completed'&&event.data.object.payment_status==='paid'){
  const s=event.data.object;console.log('PAID ORDER - needs fulfillment',s.id,s.metadata?.registryId);
 }
 res.sendStatus(200);
});
app.use(express.json({limit:'12kb'}));
app.use(express.static(new URL('.',import.meta.url).pathname,{extensions:['html']}));
app.post('/api/checkout',async(req,res)=>{
 if(!stripe||!process.env.PUBLIC_SITE_URL)return res.status(503).json({error:'Payments are not connected yet. The site owner must configure Stripe and the public website address.'});
 const {kind,items,registryId}=req.body||{};
 if(!['cat','dog'].includes(kind)||!Array.isArray(items)||items.length<1||items.length>30||!items.every(x=>Number.isInteger(x)&&x>=0&&x<products[kind].length))return res.status(400).json({error:'Invalid gift basket'});
 const registry=registries[registryId];if(!registry||registry.status!=='verified'||registry.kind!==kind)return res.status(400).json({error:'This pet registry is not verified or does not match this shop.'});
 const site=process.env.PUBLIC_SITE_URL.replace(/\/$/,'');
 try{
  const session=await stripe.checkout.sessions.create({mode:'payment',payment_method_types:['card'],line_items:items.map(i=>({price_data:{currency:'usd',unit_amount:products[kind][i][1],product_data:{name:products[kind][i][0]+' for '+registry.displayName}},quantity:1})),success_url:site+'/?payment=success&session_id={CHECKOUT_SESSION_ID}',cancel_url:site+'/?payment=cancel',metadata:{kind,registryId,coins:String(items.length)},client_reference_id:registryId});
  res.json({url:session.url});
 }catch(e){console.error(e);res.status(500).json({error:'Could not create checkout session'})}
});
app.get('/api/payment-status',async(req,res)=>{
 if(!stripe)return res.status(503).json({error:'Payments not configured'});
 const id=req.query.session_id;if(typeof id!=='string'||!/^cs_(test_)?[A-Za-z0-9_]+$/.test(id))return res.status(400).json({error:'Invalid session'});
 try{const s=await stripe.checkout.sessions.retrieve(id);res.json({paid:s.payment_status==='paid',kind:s.metadata?.kind,coins:Number(s.metadata?.coins)||0})}catch{res.status(404).json({error:'Session not found'})}
});
app.listen(Number(process.env.PORT)||3000,()=>console.log('MeowMeowWoofWoof running'));
